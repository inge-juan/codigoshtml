<?php
	phpinfo();
?>
