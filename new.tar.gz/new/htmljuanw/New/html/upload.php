<?php
$imagen = file_get_contents('php://input');
file_put_contents("imagen.jpg", $imagen);
?>
