<?php
// Leer los datos de la imagen desde la solicitud HTTP
$imagen = file_get_contents('php://input');

if ($imagen === false || strlen($imagen) == 0) {
    file_put_contents("error_log.txt", "Error: No se recibió imagen o está vacía.\n", FILE_APPEND);
    http_response_code(400);
    exit("Error al recibir la imagen.");
}

// Guardar la imagen en el servidor
$resultado = file_put_contents("imagen.jpg", $imagen);

if ($resultado === false) {
    file_put_contents("error_log.txt", "Error: No se pudo guardar la imagen.\n", FILE_APPEND);
    http_response_code(500);
    exit("Error al guardar la imagen.");
}

// Responder al ESP32 con éxito
echo "Imagen guardada correctamente.";
?>
